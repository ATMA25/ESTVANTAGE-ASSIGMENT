import csv
import sqlite3

# ..........Create connection with SQLite Database ...............

con = sqlite3.connect("business_db1")

# ........Create Output database table........
query = "create table delivaryData as select s.customerID as Customer, s.age, o.Itemname as Item, o.quantity from " \
             "(select Sales.salesID, a.customerID, a.age from Sales inner join " \
             "(select * from Customer where (age >= 18 and age <= 35)) as a  using(customerID)) as s " \
             "left join (select salesID, Itemname, quantity from Orders inner join Items using(itemID)) as o " \
             "using(salesID)"
# con.execute(query)
# con.commit()
# con.close()
# print("data Saved")

# ..........Select Query.........

cur = con.cursor()

Final_Data = "select * from delivaryData"
cur.execute(Final_Data)
Final_Data = cur.fetchall()

for d in Final_Data:
    print(d)

def schemaCall():
    schema1 = "PRAGMA TABLE_INFO(delivaryData)"
    cur.execute(schema1)
    schema1 = cur.fetchall()
    schema_list = []
    for d in schema1:
        schema_list.append(d[1])
    # print(schema_list)
    return schema_list


# # ..........Save data as CSV file with Delimiter = ";"  ...........................

with open("my_CSV_file.csv", 'w', newline='') as csvfile:
    write = csv.writer(csvfile, delimiter =";")
    write.writerow(schemaCall())
    for row in Final_Data:
        write.writerow(row)

# ............ Database Connection close ...................
cur.close()
con.close()
