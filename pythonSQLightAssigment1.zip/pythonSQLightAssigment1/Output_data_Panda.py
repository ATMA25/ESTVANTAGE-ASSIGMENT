import  csv
import  sqlite3
import pandas as pd

# ..........Create connection with SQLite Database ...............

con = sqlite3.connect("business_db1")

#  ..........Select Query.........

df = pd.read_sql_table("delivaryData")
print(df)

df.to_csv("delivaryData.csv", sep = ";", index = False)

# ............ Database Connection close ...................

con.close()
